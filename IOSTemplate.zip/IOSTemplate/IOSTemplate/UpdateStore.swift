//
//  UpdateStore.swift
//  BriterProducts
//
//  Created by Mohit Batra on 7/28/20.
//  Copyright © 2020 Mohit Batra. All rights reserved.
//

import SwiftUI
import Combine

class UpdateStore: ObservableObject {
    @Published var updates: [Update] = updateData
}
